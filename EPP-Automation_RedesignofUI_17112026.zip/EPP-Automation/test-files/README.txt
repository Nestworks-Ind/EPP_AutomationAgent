Put the JMX scripts and CSV files you want to use from the prompt box here.
