# Prompt box with GitHub Copilot: one-time setup

The EPP Automation page has a prompt box ("Ask in plain English"). You type what you want, GitHub Copilot turns it
into a plan, you check the plan and press **Yes, run it**. Copilot is reached through a small VS Code extension,
the EPP Copilot Bridge, which uses your own Copilot sign-in. No token is needed.

## Install the bridge (once)

1. Open VS Code and check you are signed in to GitHub Copilot (the Copilot icon at the top or bottom shows your account).
2. Press `Ctrl+Shift+X` to open Extensions. Click **...** at the top of the panel, choose **Install from VSIX...**
   and pick `epp-copilot-bridge-1.0.0.vsix`.
3. Press `Ctrl+Shift+P`, type **EPP Bridge: Connect to Copilot (test)** and press Enter.
   VS Code asks whether the extension may use Copilot's language models. Click **Allow**.
   You should see "EPP bridge is connected to Copilot".

## Each time

1. Open VS Code (any folder, or none). Keep it open in the background. The status bar shows **EPP bridge**.
2. Double-click `run.bat`. The page opens at http://localhost:8080 on the **Ask in plain English** tab.
   The badge next to "What do you want to do?" says **Copilot connected**.
3. Fill in Application Name, UserName and Password at the top.
4. Put your JMX and CSV files in the `test-files` folder next to `run.bat`, or click **+ Add files to test-files**.
5. Type what you want and press Enter, for example:
   - Upload SN_SC09_Search.jmx and SN_SC09_Logins.csv to Git
   - Upload the SC09 script and its CSV, then create the simulation with 1 smoke user and 25 load users for 10 minutes
   - Create only the smoke test for SN_SC06_Display with 3 users
   - Create the SmokeTest and LoadTest batch jobs for SN_SC09_Search and SN_SC06_Display in the Stage environment
   - Set up everything for SN_SC09_Search: 1 smoke user, 20 load users for 30 minutes, 2 load generators
6. Check the plan. You can change any box, or type a follow-up such as "make it 5 smoke users" or "also create the batch jobs".
7. Press **Yes, run it**. Progress shows below, as with the form.

Starting a test and Grafana monitoring are not part of the agent yet. If you ask for them, the plan says so and
does only the setup steps.

## If Copilot is not connected

The page still works: the badge shows **Built-in rules** and the prompt is read with fixed rules that understand
file names, the four activities and numbers such as "5 smoke users", "ramp-up 60 seconds" and "duration 15 min".
Always check the plan before running.

| Problem | Fix |
| --- | --- |
| Badge says Copilot not connected | Open VS Code. Click **EPP bridge** in the status bar to test it. |
| "has not allowed the EPP bridge to use Copilot" | Run **EPP Bridge: Connect to Copilot (test)** and click Allow. |
| "Install from VSIX" is missing or blocked | Your company limits extensions. Ask IT to allow it, or use the built-in rules. |
| Port 8765 already in use | Another VS Code window runs the bridge; that is fine. Or change `eppBridge.port` in VS Code settings and `ai.bridge.url` in `epp-automation.properties`. |
| You never want Copilot used | Set `ai.mode=rules` in `epp-automation.properties`. |

Each prompt uses one Copilot request. The bridge uses GPT-4.1 by default, which does not use premium requests on
paid Copilot plans. To change it, set `eppBridge.model` in VS Code settings.
