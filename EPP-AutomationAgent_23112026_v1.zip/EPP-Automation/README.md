# EPP Automation

A local web page that runs the EPP flows for you:

1. Upload JMX scripts to Git (`src/test/jmeter`), then check each file is there
2. Upload CSV test data files to Git (`target/jmeter/bin`), then check each file is there
3. Create a simulation per JMX script, with `SmokeTest_<name>` and `LoadTest_<name>` scenarios
4. Create batch: a SmokeTest job and a LoadTest job, each with the matching scenario of every simulation (job names and environment can be changed; an existing job is never changed)

You sign in once per run and are signed out at the end, whichever steps you pick. The browser is hidden
by default and the page shows plain-language progress. Tick **Show browser** to watch it.

## Test report (Excel)

The app opens on a home screen: pick **Test Design** or **Test Report**. On Test Report, paste the link of the JMeter HTML report (the `index.html` link, for example
`https://s3api-core.../2026SPPPerf2XLoadTest-789932/index.html`), fill in Application Name, Environment, Total User Count,
Response Time (SLA) in seconds, Error Percentage (SLA) in %, Test Type and Test Status, and press **Generate Report**.
The Excel file downloads by itself and is also kept in `reports\<run id>\`.

| Sheet | What it holds |
| --- | --- |
| Test Summary | Test Details (date and time in CST and IST, environment, scenarios, users, duration, type, status) and Test Summary (transaction samples, passed, failed, passed %, transactions that breached the SLA) |
| Transaction Summary | Every transaction with its 90th percentile response time (seconds) and Error %. Values above the SLA are red |
| Error Details | The report's Errors table and Top 5 Errors by sampler |
| Graphs | Pictures of Hits per second, Active Threads Over Time and Response Times Over Time (transactions only) |
| Statistics | The full Statistics table, all columns. Each transaction has its requests under it: click **+** to open it |
| Comparison Summary | Only when previous rounds are given: overview metrics per round, what changed in the latest round (faster, slower, new SLA breaches) and the top 5 slowdowns and improvements |
| Comparison Details | Every transaction's 90th percentile and Error % for each round, change vs the previous round, a Faster/Slower/Same trend, SLA met or breached; only the two header rows and the name columns are frozen, with filters |

- **Compare with previous rounds:** add the HTML report link of each earlier round (oldest first), with its Total User Count
  if you know it, and name this round. A round whose report cannot be read is left out, and the log says why.
- A transaction breaches the SLA when its 90th percentile is above the Response Time SLA, or its Error % is above the
  Error SLA. With Test Status **Auto** the status is Pass when no transaction breaches it, else Fail.
- Sheet 5 puts each request under its transaction by name: "SC01_App. 00 Launch url.-0 GET host/path" goes under
  "SC01_App. 00 Launch url.", in -0, -1, -2 order. Requests named another way are placed with the JMX script
  (choose it with **JMX script** on the page, or keep it in the `test-files` folder); any left over are listed at the
  end under "Requests not matched to a transaction".
- Total Scenarios counts the different names before the first "." in the transaction names
  (e.g. "SC01_DashboardProjectsTab_LoadDataAll"). User Count is the **Total User Count** typed on the page; left
  empty, it is the peak number of active threads in the report.
- The SLA row is named after the SLA you typed, e.g. "No of Transactions breached SLA (3 Seconds, 1% Error)".
- On sheet 5 a request is shown from its method onwards ("GET host/path"), under its transaction.
- The numbers are read from the report's own data files. The graphs are pictures of its pages, taken in a hidden
  browser; untick **Include graphs** to skip them. A link to a local report folder (such as `C:\reports\MyTest`) works too.

## Prompt box (AI)

The page opens on **Ask in plain English**: type what you want, check the plan GitHub Copilot makes, and press
**Yes, run it**. Copilot is reached through the EPP Copilot Bridge extension in VS Code. See `AI-SETUP.md` for the
one-time setup. Without VS Code the prompt box still works with built-in rules. **Fill the form** is the original page.

## Run it (Windows)

Needs only Java 8 or newer (`java -version`) and Microsoft Edge or Google Chrome. Node.js, which Playwright runs on,
is shipped in the `node` folder as `node.exe.gz.001` and `node.exe.gz.002`, so that every file stays under GitHub's
25 MB upload limit. The app joins them into `node\node.exe` on the first run.

1. Unzip `EPP-Automation.zip`, `EPP-Node-part1.zip` and `EPP-Node-part2.zip` into the same folder, such as `C:\`.
   You should end up with `C:\EPP-Automation\epp-automation.jar` and `C:\EPP-Automation\node\node.exe.gz.001` and `.002`.
2. Double-click `run.bat`. The page opens at http://localhost:8080. Keep the black window open while you use it.
3. Fill in the Global Parameters and one row per scenario, pick the steps and press **Run**.

The first run takes about 20 seconds longer while Node.js and Playwright unpack. Nothing is downloaded.
To use Chrome instead of Edge, set `browser.channel=chrome` in `epp-automation.properties`.

## What each step does

- **Sign in:** opens EPP in a private (incognito-style) window and signs in with UserName and Password.
  If Microsoft asks for an extra step such as an authenticator approval, the run stops and asks you to tick
  **Show browser** and run again, so you can approve it in the window.
- **Application:** opens the application dropdown in the black bar and picks Application Name.
- **Flows 1 and 2:** clicks "Access your GitHub Repository", continues through single sign-on, opens the
  upload page of the folder, adds all files, commits to `main`, then opens each file's page to confirm it
  exists. Any missing file is listed and the run stops.
- **Flow 3:** Test Execution > Simulations > ADD SIMULATION with Simulation Name = file name without `.jmx`
  and JMeter Test Plan = file name. It switches to 100 rows per page when needed, opens the simulation's
  scenarios, and creates the Smoke and Load scenarios (Users, TG1.RampUpPeriod, TG1.Duration, load generators,
  CPU cores, heap memory). Records that already exist are skipped, so a run can be repeated safely.
- **Sign out:** avatar at the top right > Logout.

Every step saves a screenshot under `runs\<run id>\`. If a run stops, open **Screenshots** on the page to see where.

## Settings

To change a setting, edit `epp-automation.properties` next to the jar:

| Setting | Default | Meaning |
| --- | --- | --- |
| `epp.url` | https://performance.optum.com | EPP portal |
| `github.branch` | main | Branch the files are committed to |
| `github.jmxFolder` | src/test/jmeter | Folder for JMX scripts |
| `github.csvFolder` | target/jmeter/bin | Folder for CSV files |
| `browser.channel` | msedge | `msedge` or `chrome` |
| `server.port` | 8080 | Port of the local page |
| `timeout.step.ms` | 30000 | How long to wait for a page element |
| `timeout.long.ms` | 180000 | How long to wait for sign-in, uploads and commits |

## Building from source

`mvn package` creates `target/epp-automation.jar` (compiled for Java 8; Playwright for Java, Javalin 4). That jar holds Playwright
drivers for every OS (about 200 MB). The shipped jar keeps only `driver/win32_x64` and drops `node.exe`, `lib/vite`,
`types`, `api.json` and `PrintDeps.exe`, which brings it to about 10 MB:

```
zip -d target/epp-automation.jar "driver/linux/*" "driver/linux-arm64/*" "driver/mac/*" "driver/mac-arm64/*" "driver/win32_x64/node.exe" "driver/win32_x64/package/lib/vite/*" "driver/win32_x64/package/bin/PrintDeps.exe" "driver/win32_x64/package/types/*" "driver/win32_x64/package/api.json"
```
The code is in `src/main/java/com/epp/automation`:

- `App.java`: the local web server and the run queue
- `EppFlows.java`: every browser step
- `src/main/resources/public/index.html`: the page
